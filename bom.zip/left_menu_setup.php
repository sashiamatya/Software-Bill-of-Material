<div id="menu-left">

<a href="setup_gantt_preference.php">
  	<div <?php if($left_selected == "GANTTPREFERENCE")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/gantt.png">
  	<br/>Gantt Preferences<br/></div>
  </a>

  

</div>
